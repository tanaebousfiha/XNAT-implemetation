#ReadMe

This is the official template for Master's and Bachelor's theses of the Institute of Computer Science at the Georg-August-Universität Göttingen. 

The template is available in an English as well as a German version. The template is just a proposal so feel free to adapt it to your needs.

Please note that Texlive 2018 is required for a successful compilation with pdf/a compliance.
